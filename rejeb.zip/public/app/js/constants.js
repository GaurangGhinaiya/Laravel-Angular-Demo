angular.
        module('Constants', [])

        .constant('userType', {
            'USER_TYPE_ADMIN': 1,
            'USER_TYPE_MEMBER': 2,
        })
