<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


// User Type Constant
define('USER_TYPE_ADMIN', 1);
define('USER_TYPE_MEMBER', 2);

define('ADMIN_EMAIL', 'gaurangghinaiya@yahoo.in');
